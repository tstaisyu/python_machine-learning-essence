import mod1

print(mod1.hello())
