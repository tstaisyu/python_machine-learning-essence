def meow():
    print("Meow!")


def main():
    print("Entering main")
    meow()


if __name__ == "__main__":
    main()
