def g(a, b=100):
    return a + b


print(g(3))
print(g(2, 3))
