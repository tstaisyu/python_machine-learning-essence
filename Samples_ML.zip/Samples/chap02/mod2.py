def meow():
    print("Meow!")


print("I am imported")
