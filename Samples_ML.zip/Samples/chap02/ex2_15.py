with open("sample.txt") as f:
    for line in f:
        line = line.rstrip()
        print(line)
