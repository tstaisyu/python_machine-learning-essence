a = "Hello"
b = 'Hi'
c = """Example
of
multiple
lines"""
d = '''Another
example
of
multiple
line'''
print(a)
print(b)
print(c)
print(d)
