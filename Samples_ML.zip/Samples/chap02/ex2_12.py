import mod2

print("Bowwow!")
mod2.meow()
