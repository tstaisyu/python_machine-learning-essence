def f(a, b):
    return a + b


print(f(3, 5))
print(f(2, 1))
