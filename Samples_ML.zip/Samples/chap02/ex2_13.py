import mod3


mod3.meow()
