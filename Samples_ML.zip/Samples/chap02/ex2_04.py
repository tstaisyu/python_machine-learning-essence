a = 3 \
    + 5

print(a)

b = (3
     + 5)

print(
    b)

l = [1, 2,
     3]

print(l)
