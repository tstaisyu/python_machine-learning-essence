def hello():
    return "Hello!"
