import numpy as np


def softplus(x):
    return np.log(1 + np.exp(x))
