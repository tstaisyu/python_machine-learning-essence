import numpy as np
import matplotlib.pyplot as plt

x = np.array([0, 1, 2, 3])
y = np.array([3, 7, 4, 8])

plt.scatter(x, y, color="k")
plt.show()
